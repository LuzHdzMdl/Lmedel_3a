package p3a;

public class Data {

    public Data() {
    }

    public String[] saveData(String data) {
        String[] arrData = data.split(",");
        return arrData;
    }

}