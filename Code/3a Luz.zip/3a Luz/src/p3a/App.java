package p3a;

public class App {

    public App() {
        
    }

    public static void main(String[] args) {
        Logic myLogic = new Logic();
        myLogic.logic3a();
    }

}