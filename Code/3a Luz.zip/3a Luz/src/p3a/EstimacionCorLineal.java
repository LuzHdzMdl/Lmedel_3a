package p3a;

public class EstimacionCorLineal {

    private double dblSumX;
    public double dblSumY;
    public double dblSumXY;
    public double dblSumXX;
    public double dblSumYY;
    public double dblAvgX;
    public double dblAvgY;
    public double dblB1;
    public double dblRXY;
    public double dblB0;
    public double dblR;
    public double dblXk;
    public double dblYk;
    public int intN;
    
    public EstimacionCorLineal() {

    }

    public String[] Estimacion(String[] datalist, int n) {
        int rep=n+10;
        sumX(datalist, rep);
        sumY(datalist, rep);
        sumXX(datalist, rep);
        sumXY(datalist, rep);
        sumYY(datalist, rep);
        getAvgX(n);
        getAvgY(n);
        getB1(n);
        getB0();
        getRXY(n);
        getYk();
        getR();

        String result[] = new String[12];

        result[0]= String.valueOf(dblSumX);
        result[1]= String.valueOf(dblSumY);
        result[2]= String.valueOf(dblSumXX);
        result[3]= String.valueOf(dblSumXY);
        result[4]= String.valueOf(dblSumYY);
        result[5]= String.valueOf(dblAvgX);
        result[6]= String.valueOf(dblAvgY);
        result[7]= String.valueOf(dblB1);
        result[8]= String.valueOf(dblB0);
        result[9]= String.valueOf(dblRXY);
        result[10]= String.valueOf(dblYk);
        result[11]= String.valueOf(dblR);

        return result;
    }

    public void sumX(String[] datalist, int rep) {
        dblSumX=0;
        for (int i=0; i<rep; i=i+2){
            dblSumX=dblSumX+Double.parseDouble(datalist[i]);
        }
        System.out.println("SumX = " + dblSumX);
    }

    public void sumY(String[] datalist, int rep) {
        for (int i=1; i<rep; i=i+2){
            dblSumY=dblSumY+Double.parseDouble(datalist[i]);
        }
        System.out.println("SumY = " + dblSumY);
    }

    public void sumXX(String[] datalist, int rep) {
        for (int i=0; i<rep; i=i+2){
            dblSumXX= dblSumXX + (Double.parseDouble(datalist[i]) * Double.parseDouble(datalist[i]));
        }
        System.out.println("SumXX = " + dblSumXX);
    }

    public void sumXY(String[] datalist, int rep) {
        int j=-1;
        for (int i=0; i<rep; i=i+2){
                j=j+2;
                dblSumXY= dblSumXY + (Double.parseDouble(datalist[i]) * Double.parseDouble(datalist[j]));
        }
        System.out.println("SumXY = " + dblSumXY);
    }

    public void sumYY(String[] datalist, int rep) {
        for (int i=1; i<rep; i=i+2){
            dblSumYY= dblSumYY + (Double.parseDouble(datalist[i]) * Double.parseDouble(datalist[i]));
        }
        System.out.println("SumYY = " + dblSumYY);
    }

    public void getAvgX(int n) {
        dblAvgX = dblSumX/n;
        System.out.println("AvgX = " + dblAvgX);
    }


    public void getAvgY(int n) {
        dblAvgY = dblSumY/n;
        System.out.println("AvgY = " + dblAvgY);
    }

    public void getB1(int n) {
        dblB1= (dblSumXY-(n*dblAvgX*dblAvgY))/(dblSumXX-(n*(dblAvgX*dblAvgX)));
        System.out.println("B1 = " + dblB1);
    }

    public void getRXY(int n) {
        dblRXY= (n*dblSumXY-dblSumX*dblSumY)/(Math.sqrt((n*dblSumXX-(dblSumX*dblSumX))*(n*dblSumYY-(dblSumY*dblSumY))));
        System.out.println("Rxy = " + dblRXY);
    }

    public void getB0() {
      dblB0=dblAvgY-dblB1*dblAvgX;
      System.out.println("B0 = " + dblB0);
    }

    public void getYk() {
      dblYk = dblB0 + dblB1 * 386;
      System.out.println("Yk = " + dblYk);
    }

    public void getR() {
        dblR = dblRXY * dblRXY;
        System.out.println("R^2 = " + dblR);
    }

}